#ifndef __MATROXFB_ACCEL_H__
#define __MATROXFB_ACCEL_H__

#include "matroxfb_base.h"

void matrox_cfbX_init(struct matrox_fb_info *minfo);

#endif
